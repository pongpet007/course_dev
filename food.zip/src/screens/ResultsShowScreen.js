import React ,{ useState, useEffect } from  'react';
import {View,Text,StyleSheet,Image,useWindowDimensions,ScrollView } from 'react-native';
import bdadshop from '../api/bdadshop';
import HTML from 'react-native-render-html';

const ResultsShowScreen = ({navigation})=>{
    const [results , setResults] = useState(null);
    const pro_id = navigation.getParam('id');
    const contentWidth = useWindowDimensions().width;
    // console.log(pro_id);

    const getResults = async (pro_id)=>{

        const response = await bdadshop.get(`/Product/getOne/${pro_id}`,{

        });
        setResults(response.data);
    };

    useEffect(() => {
        getResults(pro_id);
    }, []);
    // console.log(results);

    if(! results){
        return null;
    }    
    const desc = `<div> ${ results.pro_desc_en } </div>`;
    return (
        <ScrollView>
        <View style={{padding:30}}>
            <Image style={styles.imagethumbnail} source={{uri:`http://192.168.1.66:90/bdadshopapi/images/product/pro_${pro_id}01.jpg`}} />  
            <Text style={{fontSize:18,fontWeight:"bold",paddingVertical:20}}>{ results.pro_name_en }</Text>
            <HTML source={{ html: desc  }}  contentWidth={contentWidth} />
        </View>
        </ScrollView>
    );

};

const styles = StyleSheet.create({
    imagethumbnail: {
        width: '100%',
        height:500,
        borderRadius:4,        
        padding: 10
    },
});

export default ResultsShowScreen;