import React,{ useState } from 'react';
import { View, Text, StyleSheet ,ScrollView} from 'react-native';
import ResultsList from '../components/ResultsList';
import SearchBar from '../components/SearchBar';
import useResults from '../hooks/useResults';

const SearchScreen = () => {
  const [term,setTerm] = useState('');
  const [searchAPI,results,errorMessage] = useResults();
  
  // const filterResultsByPrice = (price)=>{
  //     return results.filter(result=>{
  //       return result.price===price;
  //     });
  // };

  
  return (
    
    <View style={{ flex:1}}>
      <SearchBar term={term} 
      onTermChange={ setTerm } 
      onTermSubmit={ ()=> searchAPI(term) }
      />
      <View style={{marginLeft:20}}>    
      <Text>Keyword :  {term}</Text>
      {errorMessage?<Text style={{color:'red'}}>{ errorMessage }</Text>:null}
      <Text>We have found : { results.length } results</Text>
      </View>  
      <ScrollView>
        <ResultsList results={results} title="Popular" />
        <ResultsList results={results} title="Lastest"/>
        <ResultsList results={results} title="Hot deal"/>
      </ScrollView>
    </View>
    
  );
};

const styles = StyleSheet.create({});

export default SearchScreen;
