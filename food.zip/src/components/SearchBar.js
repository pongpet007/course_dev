import React from "react";
import { View,TextInput,StyleSheet} from "react-native";
import { AntDesign } from '@expo/vector-icons'; 

const SearchBar = ({term,onTermChange,onTermSubmit})=>{
    return(
        <View style={styles.backgroundStyle}>
            <AntDesign style={styles.icon} name="search1" size={30} color="black" />
            <TextInput placeholder="Search Bar" 
            value={term} 
            onChangeText={(newterm)=> onTermChange(newterm)}
            autoCapitalize="none"
            autoCorrect={false}
            style={styles.search}
            onEndEditing={()=>{onTermSubmit()}}
            onBlur={()=>{onTermSubmit()}}
            />
        </View>
    );
};

const styles = StyleSheet.create({
    backgroundStyle:{
        marginVertical:15,
        backgroundColor:'#EEE',
        height:50,
        borderRadius:5,
        marginHorizontal:15,
        flexDirection:"row",
        alignItems: 'center'
    },
    icon:{
       fontSize:35,
       alignSelf:"center",
       marginHorizontal:15,
      
    },
    search:{        
        fontSize:18,
        flex:1
    }


});

export default SearchBar;