import React from 'react';
import {View,Image,Text,StyleSheet} from 'react-native';

const ResultDetail = ({name,id})=>{
    return (
        <View style={styles.wrap}>
            <Image style={styles.imagethumbnail} source={{uri:`http://192.168.1.66:90/bdadshopapi/images/product/pro_${id}01.jpg`}} />         
            <Text style={styles.textTitle}>{name}</Text>
        </View>
    );
};

const styles = StyleSheet.create({
    wrap:{
        marginLeft:10,
        alignItems:"center",
        borderColor:'#ccc',
        borderWidth:1,
        padding:5,
        margin:2
    },
    imagethumbnail: {
        width: 250,
        height:200,
        borderRadius:4,        
        padding: 10
    },
    textTitle:{
        fontSize:16,
        paddingVertical:10,
        width:250,
        overflow:"hidden",
        
    }
});

export default ResultDetail;