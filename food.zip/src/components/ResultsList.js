import React from 'react';
import {View , Text,StyleSheet ,FlatList,TouchableOpacity} from 'react-native';
import ResultDetail from './ResultDetail';
import { withNavigation } from 'react-navigation';

const ResultsList = ({title,results,navigation})=>{
    return (
        
        <View style={styles.wrap}>
            <Text style={styles.textHeader}>{title}</Text>
            <FlatList 
                keyExtractor={(result)=>result.pro_id}
                horizontal
                showsHorizontalScrollIndicator={false}
                data={results}
                renderItem={({item})=>{
                    return (
                        <TouchableOpacity onPress={()=>navigation.navigate('ShowScreen',{id:item.pro_id})}>
                            <ResultDetail name={item.pro_name_en} id={item.pro_id}/>
                        </TouchableOpacity>
                    );
                }}
            />
        </View>
    );
};

const styles = StyleSheet.create({
    wrap:{        
        padding:10,     
        
    },
    textHeader:{
        paddingBottom:10,
        paddingLeft:10,
        fontSize:18,
        color:'black',
        fontWeight: 'bold'

        
    }
});

export default withNavigation(ResultsList);