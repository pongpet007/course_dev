import { useState, useEffect} from 'react';
import bdadshop from '../api/bdadshop';

export default ()=>{
    const [results, setResults] = useState([]);
    const [errorMessage,setErrorMessage] = useState('');

    const searchAPI = async(newTerm)=>{
        try{
            const response = await bdadshop.get('/Product/getbyCompany/14/10',{
                params:{
                term:newTerm,
                }
            });
            setResults(response.data);
            // console.log(response.data);
        }catch(err){
            setErrorMessage('Something went wrong');
        }
        
    };
    
    useEffect(()=>{
        searchAPI('pasta');
    },[]);

    return [searchAPI,results,errorMessage];
};