import React from "react";
import { Text , StyleSheet ,View, Image } from "react-native";

const ImageDetail = props=>{
    // console.log(props);    
    return (
        <View style={{padding:5}}>

            <Image source={ props.src } style={styles.imagethumbnail}/>
            <Text>
                {props.title}
            </Text>
        </View>
    );
};


const styles = StyleSheet.create({
    imagethumbnail: {
        width: '100%',
        height: 165,
        padding: 10
      }    
});

export default ImageDetail;