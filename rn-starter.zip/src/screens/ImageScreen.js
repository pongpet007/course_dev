import React from "react";
import { Text,StyleSheet,View ,Image,ScrollView  } from "react-native";
import ImageDetail from "../component/ImageDetail";

const ImageScreen = ()=>{
    return(
        <View style={{padding:20}}>
            <ScrollView>
            <Image style={styles.imagethumbnail} source={{uri:'https://i.vimeocdn.com/portrait/58832_300x300.jpg'}}/>            
            <ImageDetail title="Beach" src={require('../../assets/beach.jpg')} />
            <ImageDetail title="Forest" src={require('../../assets/forest.jpg')} />
            <ImageDetail title="Mountain" src={require('../../assets/mountain.jpg')}/>
            </ScrollView>
        </View>
    );
};


const styles = StyleSheet.create({
    imagethumbnail: {
        width: '100%',
        height: 165,
        padding: 10
      }    
});

export default ImageScreen;