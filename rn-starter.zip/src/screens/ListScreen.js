import React from "react";
import { Text,View,StyleSheet ,FlatList } from "react-native";

const ListScreen = ()=>{
    const friends = [
        {name: 'Friend #1', key:'1'},
        {name: 'Friend #2', key:'2'},
        {name: 'Friend #3', key:'3'},
        {name: 'Friend #4', key:'4'},
        {name: 'Friend #5', key:'5'},
        {name: 'Friend #6', key:'6'},
        {name: 'Friend #7', key:'7'},
    ]
    return (
        <View>
            <Text style={styles.Header} >List Screen</Text>
            <FlatList 
            //horizontal
            // showsHorizontalScrollIndicator={false}
            keyExtractor={friend => friend.key}
            data={friends} 
            renderItem={({item})=>{
                // element=== {item:{name:'Friend #1'},index:0}
                // item === {name:'Friend #1'}
                return <Text style={styles.listitem} >{item.name}</Text>
            }}
            />
        </View>
    );
};

const styles = StyleSheet.create({
    Header:{
        fontSize:50,
        padding:10,
        textAlign:"center"
    },
    listitem:{
        padding:10,
        fontSize:16,        
        borderColor:'#ccc',
        borderWidth:1,
        borderStyle: "solid",
        margin:5
    }
});

export default ListScreen;