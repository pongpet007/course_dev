import React,{ useState } from "react";
import { View,Text,TextInput,StyleSheet } from "react-native";

const InputScreen = ()=>{
    const [text,setText] = useState('');
    return(
        <View>
            <Text>Enter name </Text>
            <TextInput 
            style={styles.input} 
            autoCapitalize="none"
            autoCorrect={false}            
            onChangeText={(newvalue)=>{ setText(newvalue)}}
            />
            <Text>Your name is : {text}</Text>
        </View>
    );
};

const styles = StyleSheet.create({
    input:{
        borderColor:'black',
        borderStyle:'solid',
        borderWidth:1,
        margin:15,
        padding:10
    }
});

export default InputScreen;