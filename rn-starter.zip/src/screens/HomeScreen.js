import React ,{useState} from "react";
import { Text, StyleSheet,View,Button } from "react-native";

const HomeScreen = (props) => {
  // console.log(props);

  const [text, setText] = useState('');
  return  (
    <View style={{padding: 10}}>
        <View style={{margin:2}} >
          <Button title="Component Demo" onPress={()=>{props.navigation.navigate("Component")}} />
        </View>
        <View style={{margin:2}}>
          <Button  title="List" onPress={()=>{props.navigation.navigate("List")}} />
        </View>     
        <View style={{margin:2}} >
          <Button title="Image" onPress={()=>{props.navigation.navigate("Image")}}/>
        </View>
        <View style={{margin:2}} >
          <Button title="Counter" onPress={()=>{props.navigation.navigate("Counter")}}/>
        </View>
        <View style={{margin:2}} >
          <Button title="Color" onPress={()=>{props.navigation.navigate("Color")}}/>
        </View>
        <View style={{margin:2}} >
          <Button title="Square" onPress={()=>{props.navigation.navigate("Square")}}/>
        </View>
        <View style={{margin:2}} >
          <Button title="Input" onPress={()=>{props.navigation.navigate("Input")}}/>
        </View>
        <View style={{margin:2}} >
          <Button title="Box" onPress={()=>{props.navigation.navigate("Box")}}/>
        </View>
    </View>
   
  );
};

const styles = StyleSheet.create({
  text: {
    fontSize: 60,
    textAlign:"center"
  },
  mb15:{
    margin:20,
    marginBottom:50
  }

});

export default HomeScreen;
