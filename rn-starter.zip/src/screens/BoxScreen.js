import React from "react";
import {View,Text,StyleSheet  } from "react-native";

const BoxScreen = ()=>{

    return (
        <View>
            <View>
                <Text style={styles.box}>Box on screen</Text>
            </View>
            <View style={styles.wrapBox}>
                <Text style={styles.boxFlex}>Child #1</Text>
                <Text style={styles.boxFlex}>Child #2</Text>
                <Text style={styles.boxFlex}>Child #3</Text>
            </View>
        </View>
    );
};

const styles = StyleSheet.create({
    box:{
        margin:20,
        padding:20,
        borderColor:"black",
        borderStyle:"solid",
        borderWidth:1,
        textAlign:"center"

    },
    wrapBox:{
        alignItems:"flex-end",
        flexDirection:"row-reverse",        
    },
    boxFlex:{
        padding:20,
        borderColor:"pink",
        borderStyle:"solid",
        borderWidth:1,      
    }
});

export default BoxScreen;